#include <iostream>
#include <cmath>
#include <stdlib.h>
using namespace std;
int H[100], n, x;
void Insert(int& n, int H[], int x) //functie pentru inserarea elem. in H
{
    int niv, fiu, tata;
    H[++n]=x;
    if (n>1)
    {
        fiu=n; //pozitia curenta a valorii x
        niv=(int)log2(n); //nivelul pe care este inserat noul nod
        if (niv%2==0) //nodul este inserat pe un nivel minim
        {
            tata=n/2; //nodul tata situat pe nivel maxim
            if(x>H[tata])//compar cu nodurile maxime de pe drumul spre radacina
            {
                while (tata && x>H[tata])
                {
                    H[fiu]=H[tata];
                    fiu=tata;
                    tata=fiu/4;
                }
                H[fiu]=x;
            }
            else //compar cu nodurile minime de pe drumul spre radacina
            {
                tata=fiu/4;
                while (tata && x<H[tata])
                {
                    H[fiu]=H[tata];
                    fiu=tata;
                    tata=fiu/4;
                }
                H[fiu]=x;
            }
        }
        else //nodul este inserat pe un nivel maxim
        {
            tata=n/2; //nodul tata situat pe nivel minim
            if(x<H[tata])//compar cu nodurile minime de pe drumul spre radacina
            {
                while (tata && x<H[tata])
                {
                    H[fiu]=H[tata];
                    fiu=tata;
                    tata=fiu/4;
                }
                H[fiu]=x;
            }
            else //compar cu nodurile maxime de pe drumul spre radacina
            {
                tata=fiu/4;
                while (tata && x>H[tata])
                {
                    H[fiu]=H[tata];
                    fiu=tata;
                    tata=fiu/4;
                }
                H[fiu]=x;
            }
        }
    }
}

int MinNepot(int poz) //functie care returneaza indexul nepotului min al nodului de pe poztia "poz"
{
    int min_nepot=INT_MAX, p;
    for(int j=4*poz; j<=4*poz+3 && j<=n; j++)  //parcurg in H nepotii nodului respectiv
        if(H[j]<min_nepot)   //in cazul in care nepotul de pe poztia j este mai mic decat cel mai mic nepot,
        {
            min_nepot=H[j];  //acesta devine nepot minim
            p=j;            //se actualizeaza si pozitia nepotului minim
        }
        return p;           //se returneaza pozitia nepotului minim
}

int MinFiu(int poz)
{
    int min_fiu=INT_MAX, p;
    for(int j=2*poz; j<=2*poz+1 && j<=n; j++) ////parcurg in H fiii nodului respectiv
        if(H[j]<min_fiu) //in cazul in care fiul de pe poztia j este mai mic decat cel mai mic fiu,
        {
            min_fiu=H[j]; //acesta devine fiu minim
            p=j;          //se actualizeaza si pozitia fiului minim
        }
        return p;         //se returneaza pozitia fiului minim
}

int ExtractMin(int H[], int& n)  //extragere nod minim
{
    int poz=1, x;
    int gata=0; //gata va fi 1 c�nd terminam comparatiile pe niveluri minime
    int v=H[n--], rez=H[1];
    while (!gata && 4*poz <= n)
    {
        x= MinNepot(poz); //x este pozitia celui mai mic nepot al nodului de pe pozitia poz
        if (v<H[x])
            gata =1;
        else
        {
            H[poz]=H[x];
            poz=x;
        }
    }
    H[poz]=v;
//compar cu nodurile de pe nivelul maxim urmator
    x=MinFiu(poz); //x este pozitia celui mai mic fiu al nodului de pe pozitia poz
    if (x <= n) //exista cel putin un fiu
        if (v>H[x])
            {
                H[poz]=H[x];
                H[x]=v;
            }
    return rez;
}

int MaxNepot(int poz) //functie care returneaza indexul nepotului max al nodului de pe poztia "poz"
{
    int max_nepot=INT_MIN, p;
    for(int j=4*poz; j<=4*poz+3 && j<=n; j++) //parcurg in H nepotii nodului respectiv
        if(H[j]>max_nepot) //in cazul in care nepotul de pe poztia j este mai mare decat cel mai mare nepot,
        {
            max_nepot=H[j]; //acesta devine nepot maxim
            p=j;    //se actualizeaza si pozitia nepotului maxim
        }
        return p; //se returneaza pozitia nepotului maxim

}

int MaxFiu(int poz) //functie care returneaza indexul fiului max al nodului de pe poztia "poz"
{
    int max_fiu=INT_MIN, p;
    for(int j=2*poz; j<=2*poz+1 && j<=n; j++) //parcurg in H fiii nodului respectiv
        if(H[j]>max_fiu) //in cazul in care fiul de pe poztia j este mai mare decat cel mai mare fiu,
        {
            max_fiu=H[j]; //acesta devine fiu maxim
            p=j;  //se actualizeaza si pozitia fiului maxim
        }
        return p; //se returneaza pozitia fiului maxim
}

int ExtractMax(int H[], int& n) //extragere nod maxim
{
    int poz=2, x, gata=0;
    if (n==1) //exista un singur nod
        {
            n=0;
            return H[1];
        }
    int rez=H[2], v;
    if (n>2 && H[3]>H[2])
    {
        rez=H[3]; poz=3;
    }
    v=H[n--]; // restauram min-max heap-ul
    while (!gata && 4*poz <=n)
    {
        x=MaxNepot(poz);//x este pozitia celui mai mare nepot al nodului poz
        if (v>H[x])
            gata=1;
        else
            {
                H[poz]=H[x];
                poz=x;
            }
    }
    H[poz]=v;
//compar cu nodurile de pe nivelul minim urmator
    x=MaxFiu(poz); //x este pozitia celui mai mare fiu al nodului poz
    if (x <= n) //exista cel putin un fiu
        if (v<H[x])
            {
                H[poz]=H[x];
                H[x]=v;
            }
    return rez;
}

void meniu()
{
    cout<<"Meniu min-max heap"<<endl;
    cout<<"-----------------------------------------------"<<endl;
    cout<<"Optiuni:"<<endl;
    cout<<"1: Creare min-max heap prin inserare"<<endl;
    cout<<"2: Afisare element maxim + stergere din heap"<<endl;
    cout<<"3: Afisare element minim + stergere din heap"<<endl;
    cout<<"4: Afisare min-max heap"<<endl;
    cout<<"0: Iesire"<<endl<<endl;
}

int main()
{
    meniu();
    int op;
    cout<<"Optiunea: ";
    cin>>op;
    while(op!=0)
    {
        switch (op)
            {
                case 1:
                    {
                    cout<<"Numar noduri= ";
                    cin>>n;
                    cout<<"Introduceti nodurile: ";
                    cin>>x;
                    H[1]=x;
                    for(int i=2; i<=n; i++)
                    {
                        int j=i-1;
                        cin>>x;
                        Insert(j, H, x);
                    }
                    break;
                    }
                case 2:
                    {
                        cout<<"Maximul este: "<<ExtractMax(H,n)<<endl;
                        break;
                    }
                case 3:
                    {
                        cout<<"Minimul este: "<<ExtractMin(H, n)<<endl;
                        break;
                    }

                case 4:
                    {
                        cout<<"Min-max heap: ";
                        for(int i=1; i<=n; i++)
                            cout<<H[i]<<" ";
                        cout<<endl;
                        break;

                    }
                default:
                    {
                        cout<<"Optiune inexistenta"<<endl;
                        break;
                    }
            }
            cout<<"Optiunea: ";
            cin>>op;
    }
	return 0;
}
